<?php

//criando rotas

session_start();

if (!isset($_SESSION['tipo_usuario']) || $_SESSION['tipo_usuario'] != "1") {
    header("Location: /");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="views/css/style.css">
        <link rel="stylesheet" href="views/css/stylecrud.css">
        <link rel="stylesheet" href="views/css/stlylemodal.css">
        
        <title>Biblioteca Científica Digital</title>
    </head>

    <body>
        <header>
            <div class = "container">
                <div class = "logo"><a href="indexSecretário.html"><img src="views/img/logo.png" style="width: 200px; height: 120px;"></a></div>
                <div class = "menu">
                    <nav>
                        <a href="IndexSecretário.html#Sobre">Sobre</a>
                        <a href="IndexSecretário.html#Colaborador">Quero ser colaborador</a>
                        <a href="IndexSecretário.html#Artigo">Submeta seu artigo</a>
                        <a href="eventos.html">Eventos</a>
                        <a href="/homeAdm">Menu</a>
                    </nav>
                </div>

                <div class="login">
                    <?php echo '<p>Bem-vindo, ' . $_SESSION['nome_usuario'] . '!</p>'; ?>
                    </br>
                    <button id="btn1">Sair</button>
                </div> 
                  
            <div>
        </header>  

        <section>
            <!-- Modal de Logout -->
            <div id="modal1" style="display: none;">
                <div id="modal" class="modal">
                    <div class="modal-content">
                        <div class="fora-form">
                            <form method="post" action="">
                                <div class="dentro-form">
                                    <h2>Deseja Sair do Sitema?</h2></br>
                                    <div style = "text-align:center; margin-left: auto; margin-right: auto;">
                                        <button type="submit">Confirmar</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <button type="button" id="cancel-button1">Cancelar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Adicionar Evento -->
            <div id="modal2" style="display: none;">
                <div id="modal" class="modal">
                    <div class="modal-content">
                        <div class="fora-form">
                            <form method="post" action="">
                                <div class="dentro-form">
                                    <h1>Adicionar novo evento</h1></br>
                                    <div class= "form-dados">
                                        <label for="nome">Nome do Evento:</label></br>
                                        <input type="nome" id="nome" name="nome" placeholder="" required></br>
                                        <label for="ano">Ano:</label></br>
                                        <input type="number" id="ano" name="ano" placeholder="" maxlength="4" required></br>
                                        <label for="organizador">Organizador:</label></br>
                                        <input type="organizador" id="organizador" name="organizador" placeholder="" required></br>
                                        <label for="ano">Tipo:</label></br>
                                        <input type="text" id="tipo" name="tipo" placeholder="" required></br>
                                        <label for="link">Link do Evento:</label></br>
                                        <input type="link" id="link" name="link" placeholder="" required></br>
                                        <label for="descrição">Descrição:</label></br>
                                        <input type="text" id="descrição" name="descrição" placeholder="" required></br>
                                        <label for="ano">Trilha:</label></br>
                                        <input type="text" id="ano" name="trilha" placeholder=""></br>
                                    </div>
                                    <div style = "text-align:center; margin-left: auto; margin-right: auto;">
                                        <button type="submit">Confirmar</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <button type="button" id="cancel-button2">Cancelar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Verificar Evento -->
            <div id="modal3" style="display: none;">
                <div id="modal" class="modal">
                    <div class="modal-content">
                        <div class="fora-form">
                            <form method="post" action="">
                                <div class="dentro-form">
                                    <h1>Dados evento</h1></br>
                                    <div class= "form-dados">
                                        <label for="nome">Nome do Evento:</label></br>
                                        <input type="nome" id="nome" name="nome" placeholder="" required></br>
                                        <label for="ano">Ano:</label></br>
                                        <input type="number" id="ano" name="ano" placeholder="" maxlength="4" required></br>
                                        <label for="organizador">Organizador:</label></br>
                                        <input type="organizador" id="organizador" name="organizador" placeholder="" required></br>
                                        <label for="ano">Tipo:</label></br>
                                        <input type="text" id="tipo" name="tipo" placeholder="" required></br>
                                        <label for="link">Link do Evento:</label></br>
                                        <input type="link" id="link" name="link" placeholder="" required></br>
                                        <label for="descrição">Descrição:</label></br>
                                        <input type="text" id="descrição" name="descrição" placeholder="" required></br>
                                        <label for="ano">Trilha:</label></br>
                                        <input type="text" id="ano" name="trilha" placeholder=""></br>
                                    </div>
                                    <div style = "text-align:center; margin-left: auto; margin-right: auto;">
                                        <button type="submit">Confirmar</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <button type="button" id="cancel-button3">Cancelar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Editar Evento -->
            <div id="modal4" style="display: none;">
                <div id="modal" class="modal">
                    <div class="modal-content">
                        <div class="fora-form">
                            <form method="post" action="">
                                <div class="dentro-form">
                                    <h1>Editar Evento</h1></br>
                                    <div class= "form-dados">
                                        <label for="nome">Nome do Evento:</label></br>
                                        <input type="nome" id="nome" name="nome" placeholder="" required></br>
                                        <label for="ano">Ano:</label></br>
                                        <input type="number" id="ano" name="ano" placeholder="" maxlength="4" required></br>
                                        <label for="organizador">Organizador:</label></br>
                                        <input type="organizador" id="organizador" name="organizador" placeholder="" required></br>
                                        <label for="ano">Tipo:</label></br>
                                        <input type="text" id="tipo" name="tipo" placeholder="" required></br>
                                        <label for="link">Link do Evento:</label></br>
                                        <input type="link" id="link" name="link" placeholder="" required></br>
                                        <label for="descrição">Descrição:</label></br>
                                        <input type="text" id="descrição" name="descrição" placeholder="" required></br>
                                        <label for="ano">Trilha:</label></br>
                                        <input type="text" id="ano" name="trilha" placeholder=""></br>
                                    </div>
                                    <div style = "text-align:center; margin-left: auto; margin-right: auto;">
                                        <button type="submit">Confirmar</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <button type="button" id="cancel-button4">Cancelar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Remover Evento -->
            <div id="modal5" style="display: none;">
                <div id="modal" class="modal">
                    <div class="modal-content">
                        <div class="fora-form">
                            <form method="post" action="">
                                <div class="dentro-form">
                                    <h1 style="text-align: center;">Removendo Evento</h1></br>
                                    <h2 style="text-align: center;">Aviso:</h2></br>
                                    <h3 style="text-align: center;">Você realmente deseja apagar o evento?</h3></br>
                                    <div style = "text-align:center; margin-left: auto; margin-right: auto;">
                                        <button type="submit">Confirmar</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <button type="button" id="cancel-button5">Cancelar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="dentro-bloco" >
                <h3>Gerenciar Eventos</h3>
            </div>    
                
            <div class="bt-container">
                <button id = "btn2">Adicionar novo evento</button> 
            </div>      
                
            <div class="container_table"> 
               <!--Caixa inteira...-->
                <!--MENU-->

                <div style="padding-top: 70px;padding-bottom: 90px;">
                    <div>
                        <div class="itens_menu_esq"><a style="color: white;" href="/organizadoresAdm">Gerenciar Organizadores</a></div>  
                        <div class="itens_menu_esq"><a style="color: white;" href="/eventosAdm">Gerenciar Eventos</a></div> 
                        <div class="itens_menu_esq"><a style="color: white;" href="/autoresAdm">Gerenciar Autores</a></div>   
                        <div class="itens_menu_esq"><a style="color: white;" href="/artigosAdm">Gerenciar Artigos</a></div>
                        <div class="itens_menu_esq"><a style="color: white;" href="/secretario">Gerenciar Secretários</a></div>
                    </div>
                </div>
                    
                <table>
                    <thead>
                        <tr>
                            <th>Nome do Evento</th>
                            <th>Ano</th>
                            <th>Organizador</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>CNSI 1999 - Congresso Nacional de Sistemas de Informação</td>
                            <td>2023</td>
                            <td>Helon</td>
                            <td>
                                <button type="button" id = "btn3">Verificar</button>
                                <button type="button" id = "btn4">Editar</button>
                                <button type="button" id = "btn5">Remover</button>
                            </td>
                        </tr>

                        <tr>
                            <td>CNSI 2000 - Congresso Nacional de Sistemas de Informação</td>
                            <td>2023</td>
                            <td>Pablo</td>
                            <td>
                                <button type="button" >Verificar</button>
                                <button type="button" >Editar</button>
                                <button type="button" >Remover</button>
                            </td>
                        </tr>

                        <tr>
                            <td>CNCC 1999 - Congresso Nacional de Ciência da Computação</td>
                            <td>2023</td>
                            <td>Vanessa</td>
                            <td>
                                <button type="button" >Verificar</button>
                                <button type="button" >Editar</button>
                                <button type="button" >Remover</button>
                            </td>
                        </tr>

                        <tr>
                            <td>CBBM 2003 - Congresso Brasileiro de Biomedicina </td>
                            <td>2023</td>
                            <td>Thiago</td>
                            <td>
                                <button type="button" >Verificar</button>
                                <button type="button" >Editar</button>
                                <button type="button" >Remover</button>
                            </td>
                        </tr>

                        <tr>
                            <td>SSI 2010 - Semana de Sistemas de Informação UFRRJ</td>
                            <td>2023</td>
                            <td>Helon</td>
                            <td>
                                <button type="button" >Verificar</button>
                                <button type="button" >Editar</button>
                                <button type="button" >Remover</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
             
        </section>

        
        <script src="../../../js/jquery-3.6.0.min.js"></script>  
        <script>
            $(document).ready(function(){
                $("#btn1").click(function(){
                    $("#modal1").show();
                });              
                $("#cancel-button1").click(function(){
                    $("#modal1").hide();
                });
                $("#btn2").click(function(){
                    $("#modal2").show();
                });              
                $("#cancel-button2").click(function(){
                    $("#modal2").hide();
                });
                $("#btn3").click(function(){
                    $("#modal3").show();
                });              
                $("#cancel-button3").click(function(){
                    $("#modal3").hide();
                });
                $("#btn4").click(function(){
                    $("#modal4").show();
                });              
                $("#cancel-button4").click(function(){
                    $("#modal4").hide();
                });
                $("#btn5").click(function(){
                    $("#modal5").show();
                });              
                $("#cancel-button5").click(function(){
                    $("#modal5").hide();
                });
            });        
        </script>

        <footer>
            <div class="wrapper">
                <div class="company-footer">
                    <img src="views/img/logo.png" style="width: 200px; height: 120px;">
                    <div class="text">   
                        <h2>BCD © 2023 | All rights reserved.</h2>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>