<?php


abstract class Pessoa {
    protected int $id;
    protected string $nome;
    protected string $telefone;
    protected string $DataDeNascimento;
    protected string $sexo;
    protected string $CurriculoLattes;
    protected string $instituicao;
    

}


?>